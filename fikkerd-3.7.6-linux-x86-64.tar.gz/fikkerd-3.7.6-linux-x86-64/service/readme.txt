1. 在 Linux 下面, 设置 Fikker 为自动运行服务:
   
   a. install.sh - 将 Fikker 注册成 Linux 服务, 操作系统重启后将会自动运行 Fikker;
   
   b. uninstall.sh - 将 Fikker 从已有的 Linux 自动服务列表中注销;
   
   c. start.sh - 如果 Linux 服务列表中包含有 Fikker 服务, 则开始运行 Fikker;
   
   d. stop.sh - 如果 Linux 服务目前在运行中, 则停止运行 Fikker;
   
2. 特别注意： 必须在当前 service 目录下, 使用根用户(root)权限运行如上脚本.
   
3. 举例 1: 安装 Fikker 到自动启动服务列表
   [user@localhost service]$ sudo ./install.sh
   
4. 举例 2: 立即运行 Fikker 服务
   [user@localhost service]$ sudo ./start.sh
